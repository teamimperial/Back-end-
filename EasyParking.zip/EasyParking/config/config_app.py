from flask import Flask

app = Flask(__name__)

SECRET_KEY = 'AJhsbd#1jb*sda'

